package customersimulation2;
/**
   The <code>Info</code> class creates random names and ages for <code>Customer</code> .
   @author Minh Nguyen <minhnguyen_2024@depauw.edu
*/

import java.util.Random;

public class Info {
    int[] ages = new int[100];
    Random random;
    String[] names = {"Brian", "George", "Scott", "Minh", "Chad", "Steven", "Alicia", "Alex", "Brandon", "Max", "DeJuan", "Jacob", "Damir"};

    public Info(){
        for (int i = 0; i < 100; i++){
            ages[i] = i;
            this.random = new Random();
        }
    }

    public int getRandomAge(){
        return ages[random.nextInt(ages.length)];
    }
    
    public String getRandomName(){
        return names [random.nextInt(names.length)];
    }

}
